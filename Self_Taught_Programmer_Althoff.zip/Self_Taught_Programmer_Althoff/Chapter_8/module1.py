print("Hello!")
